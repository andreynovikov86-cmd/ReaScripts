# ArticulationBox user guide

**English** · [Русский](USER_GUIDE_RU.md) · [Repository](https://github.com/andreynovikov86-cmd/ReaScripts)

Open **Help** in the field's full menu for short explanations without an internet connection. The quick menu contains ready articulation choices and saved independent Controller presets. The full menu keeps these choices under Articulations to remain short with large banks.

## 1. Quick start

1. Open a MIDI item and keep Articulation_Manager.lua running.
2. Create a bank: Settings > Banks > New.
3. Add / Edit articulation: if Empty bank is selected, create a named bank first. Then configure mappings. Use Save & Next to build a bank quickly.
4. Select musical notes, open the field menu and choose an articulation.
5. Optional: Default articulation for notes without an override.
6. Save the REAPER project.

Assign Articulation_Quick_Menu.lua to a MIDI Editor shortcut for ready articulation and controller choices at the mouse cursor.

## 2. Articulations and defaults

Channel: routes musical notes to a channel.
Keyswitch: sends a MIDI note that selects a sound in your instrument.
KS + Channel: combines both methods.

Add / Edit articulation opens one compact parameter window. Bank shows the destination. Articulation selects Add New or a saved mapping. New names start empty. Add variant copies the selected name and settings into a new mapping, leaving the original intact. For keyswitch variants it first asks for a group name. Group name is shown when editing a velocity group and renames its submenu without changing variant names. Edit the copied name as needed; Save & Next still clears the name. Remove articulation deletes the selected mapping from this bank, preserving existing MIDI assignments. Keyswitch, Channel and KS + Channel show their relevant parameters and can include a linked Controller. Controller saves an independent preset. Ending saves an independent keyswitch at the end of a note. Channel sets the musical-note channel; KS channel sets the keyswitch channel. KS channel 0 uses the musical note's channel.

Playing a MIDI key or clicking a piano-roll key automatically fills KS note and velocity. A mapped key also loads its saved name and parameters; an exact velocity match selects that variant. An unmapped key switches to Add New with an empty name, so the previous mapping is kept. Both values remain editable. Save stores changes without closing the window. Save & Next stores the current mapping and always switches to Add New with an empty name and the current parameters. The last saved name stays visible. Piano-roll row names update immediately after every save. Cancel discards only the current unsaved entry. Resize the window by its edges; its size is remembered.

Mappings on the same keyswitch pitch and routing with different velocities are grouped in a submenu. Variants are sorted from higher to lower velocity; Group name sets the submenu title independently; older groups use the highest-velocity name until renamed. Each variant keeps its own name and velocity.

Select notes and choose a name to apply it. Clear articulation removes the explicit override; a configured default can apply again. Defaults require a keyswitch mapping.

The field shows the selected articulation, Mixed for different assignments, or a dash if none is assigned. With no notes selected, it shows the default name, if configured.

## 3. Banks and saving

Banks selects the current track's bank. Settings > Banks creates, renames, removes, imports or exports banks. Export saves all banks of the current track.

Track banks are independent. New tracks start with Empty bank; saved bank templates remain available. Bank and articulation edits are saved automatically. Save the project to retain track bank choices and note assignments.

Appearance and common playback preferences persist between REAPER sessions. Timing changes also update the current bank's mappings.

Removing a bank or mapping does not erase existing MIDI assignments. Use Clear articulation on notes when you want to remove their overrides.

## 4. Manual keyswitches

Draw or edit notes directly on mapped articulation rows. They are treated as manual switches and do not receive a default articulation. With no default, their last switch remains active until another switch. With a default configured, manual switches override notes in their drawn region; later unassigned notes return to the default.

A later switch shortens the earlier keyswitch at its start. Different switches at exactly the same time on one channel remain ambiguous.

Independently editing an automatic keyswitch's pitch, position, length or velocity makes it manual and removes its former automatic links. Musical notes are preserved. Move the musical note instead to keep an automatic link.

## 5. Playback and timing

Trigger chooses Before note start or After note start. Delay (ms) sets the distance in milliseconds; Trigger chooses which side of the note start it applies to. Automatic keyswitches end with their musical notes, or sooner if another switch intervenes. Length/Overlap are legacy compatibility values.

For a loop ending, use After note start and a suitable Delay. KS velocity is independent of musical velocity: a chord with velocity 1 can trigger a keyswitch with velocity 100. The script preserves the chord velocity. MIDI tick resolution can impose a minimum delay.

Keyswitch timing updates the current bank and its assignments in the active take, preserving each mapping's Before/After direction; new articulations use the saved timing defaults.

Chase MIDI note-ons enables REAPER's option to resend sustained notes when playback starts inside them. Test the result with your instrument.

Auto-stagger conflicting notes delays conflicting musical starts slightly and shortens notes by the same amount, keeping their ends fixed. Spacing sets the delay in ms. It does not provide independent simultaneous articulations on one MIDI channel.

## 6. Editing and transposition

Keep the main script running while editing. Moving or resizing musical notes updates their linked automatic keyswitches. Returning notes to the same articulation can restore starts previously delayed by auto-stagger.

At the item start, or with auto-stagger enabled when neighboring starts leave no MIDI tick for a switch, a musical note can move slightly later to leave room for a Before keyswitch; its end stays fixed. After keyswitches do not require this advance space.

Broad selection/transposition protects keyswitch pitches while musical notes change pitch. With item/take pitch changes, the script writes the transpose into musical notes and resets the take pitch control, so the P+ value may disappear.

Use REAPER Undo to reverse an edit. Protection and following require the running main script.

## 7. Tools and troubleshooting

Name keyswitch rows labels piano-roll rows from the bank.
Refresh keyswitches rebuilds automatic switches in the active take from assignments.
Clear missing keyswitch assignments removes stale links after switches were deleted; a default may then apply.
Legacy keyswitches > Find for review selects possible older switches. Review the selection before Remove reviewed; manual switches can match too.
Status shows the latest operation message.

The parameter editor requires ReaImGui, installed through ReaPack. Restart REAPER after installing the extension.

No sounds change: check the instrument mapping, MIDI channel and velocity. Empty menu: choose this track's bank and add mappings. An articulation-only menu has no settings: use the field or Articulation_Menu_Popup.lua for Help and Settings.

## 8. Field, actions and startup

Articulation_Manager.lua runs the embedded field and background updates.
Articulation_Quick_Menu.lua opens only articulations at the mouse cursor.
Articulation_Menu_Popup.lua opens the full menu.

Lock position prevents moving/resizing the field. Turn it off to drag the field or its edges. Appearance and position also offers numeric position, size and font settings.
Run script on startup starts the main script with REAPER. Close field stops it for this session; disable startup separately if needed.

Detailed English and Russian guides are included as USER_GUIDE.md and USER_GUIDE_RU.md beside the scripts and linked from the GitHub README.

## Articulation parameters

| Field | Meaning |
| --- | --- |
| Name | The label shown in the articulation menu and on keyswitch rows. |
| Channel | Destination channel for musical notes (1–16), used by channel-based mappings. |
| KS note | MIDI note number (0–127) required by the instrument. New mappings use the active piano-roll row; the open editor also learns new MIDI note-ons or piano-roll key clicks; the number avoids octave-label differences between instruments. |
| KS velocity | Keyswitch velocity (1–127). Some libraries use velocity to select a variant. |
| Trigger | Before note start or After note start. |
| Delay (ms) | Timing distance from the musical-note start. MIDI tick resolution, available item space and neighboring switches can limit this. |
| KS channel | Channel used for the keyswitch. 0 follows the musical note's channel; 1–16 chooses an explicit channel. |

Mappings are listed by descending KS pitch: higher pitches appear first. A checkmark identifies an articulation used by selected notes; when a selection is mixed, note counts indicate how many notes use each entry. Changing a bank mapping does not rewrite every old assignment in every item: existing assignments keep their saved mapping. Reapply the articulation to selected notes to use a revised pitch/channel mapping. The timing tool can refresh current-bank timings in the active take.

## Menu reference

| Menu item | What it does |
| --- | --- |
| Clear articulation | Removes the explicit assignment from selected musical notes. A configured default can apply again. |
| Add / Edit articulation | Opens the bank’s parameter window. Select Add New to add, or select a saved entry to edit. Remove articulation inside the window deletes the selected mapping while preserving existing MIDI assignments. |
| Articulations | Opens the bank’s articulation choices. Velocity variants on the same KS pitch and routing are grouped in submenus. The shortcut quick menu opens choices directly. |
| Banks | Selects the active bank for this track. |
| Settings > Banks > New / Rename / Remove | Manages bank mappings. Other tracks retain independent copies. |
| Settings > Banks > Import / Export | Imports a bank file or exports all banks of the current track. Keep exported files as backups. |
| Settings > Appearance and position > Field position | Sets the horizontal position and bottom margin in the MIDI editor. |
| Settings > Appearance and position > Size and font | Sets field width, height and font size. |
| Settings > Legacy keyswitches > Find for review | Selects possible switches created before managed ownership markers; review them first. |
| Settings > Legacy keyswitches > Remove reviewed | Deletes the reviewed selection only after the script's safety checks. |
| Settings > Name keyswitch rows | Adds articulation names to mapped piano-roll rows. |
| Default articulation | Selects the fallback keyswitch articulation or disables it with None. Channel-only mappings cannot be defaults. |
| Settings > Keyswitch timing | Sets timing distance/compatibility length for current-bank mappings, keeping each mapping’s Before/After direction, refreshes their assignments in the active take, and saves defaults for new mappings. Overlap is retained for compatibility with older timing behavior. |
| Settings > Chase MIDI note-ons | Toggles REAPER's note-chase option for starting playback inside sustained MIDI notes. |
| Settings > Auto-stagger conflicting notes | Enables small start delays to resolve different automatic articulations at one onset/channel. Ends stay fixed. |
| Settings > Auto-stagger spacing | Sets the delay between conflicting starts (0.1–50 ms). MIDI tick resolution can impose a larger minimum. |
| Settings > Clear missing keyswitch assignments | Clears assignments whose managed switches are missing. A default may apply afterward. |
| Settings > Refresh keyswitches | Rebuilds automatic switches in the active take from stored assignments. |
| Settings > Status | Shows the latest operation result or error. |
| Settings > Run script on startup | Toggles automatic startup with REAPER. |
| Settings > Close field | Stops the main script for this session. |
| Help | Opens the built-in help topics and current status. |
| Lock position | Prevents dragging or resizing the embedded field. |

## Example: a delayed ending

Choose **Keyswitch**, set **Trigger > After note start**, then enter **Delay (ms)** and the instrument’s required KS note and velocity. For example, a chord at velocity 1 can send an ending keyswitch at velocity 100, 1 ms after the chord starts. The chord velocity is preserved. Automatic keyswitches follow the musical note’s end; a later switch can shorten them. If the delay exceeds the note duration, the switch uses the minimum one-tick length inside the item.

For MIDI input, the editor reads incoming note-on pitch and velocity. Piano-roll key clicks use the active row and REAPER’s default note velocity. Captured values remain editable until another key is played. Learning does not insert or record notes.

**Save** keeps the window open. **Save & Next** saves the current mapping and always selects **Add New**, clearing the name and retaining the other parameters. The saved name remains visible. **Add variant** starts a new mapping with copied parameters and an empty name. Piano-roll names refresh immediately after each save. Closing the editor discards only the current unsaved entry; earlier entries stay saved.

## Example: a default and an exception

Choose your sustained articulation under **Default articulation**. Select a few musical notes and apply Staccato. Notes without an explicit override use the default again at their starts, except where a manually drawn switch intentionally controls the channel. A default cannot provide a different simultaneous sound to another note on the same channel: use suitable instrument routing or auto-stagger where appropriate.

Automatic following, default maintenance, overlap trimming and pitch protection require the main script to remain running. Save projects and export banks before transferring your setup to another computer.

## Controllers

Choose Controller in Add / Edit articulation to save a named, independent preset. It appears under Controller in the full and quick menus. This submenu is also available to reset controllers linked to articulations or assigned to selected notes. Applying it preserves the selected notes' articulation. Other articulation types can include a linked Controller; choose None to leave it disabled.

The chooser starts with None (unassigned), followed by Pitch Bend, Mod Wheel (CC 1), Hold Pedal (CC 64), and the other CC numbers. Visiting Controller does not automatically assign Pitch Bend. CC values range from 0 to 127. Pitch Bend ranges from -8192 to 8191, with 0 at center. Hold Pedal normally uses 127 to hold and reset 0 to release.

Length: Full note sets the value before note-on and resets after note-off. Note start makes a short pulse across note-on. Note end sets the value while the note is still held and resets after note-off. Before and After set these margins in milliseconds, with at least one MIDI tick on either side. Reset value is the value sent at the end. Control channel 0 follows the musical note's channel.

Controllers follow musical note moves and length edits while the manager runs. At the item start, a note may move slightly later to leave room; at the end, the item may extend to play the reset. Undo/Redo keeps these changes together.

Controllers affect every sounding voice on their MIDI channel. Overlapping notes cannot have independent controller states on the same channel. A later assignment on the same controller lane replaces its earlier state. An independent preset overrides a linked controller on that lane until the articulation is applied again. Other controller lanes remain assigned.

**Controller > Reset controllers** removes all controller assignments from selected notes while preserving their articulation. It is disabled when no selected notes have controllers. Settings > Clear controller assignments provides the same operation. Removing a preset from the bank preserves existing MIDI assignments. Controller presets are saved with this track's bank.

When **Empty bank** is selected, **Add / Edit articulation** first opens **New bank**. Enter a name: the bank is saved and selected before the editor opens. Cancel creates no bank or articulation. The name field is widened in both creation and rename dialogs. A checkmark beside an articulation indicates its assignment to selected notes; it does not indicate whether the mapping was saved.

**Default articulation** is in the full menu directly below **Banks**. It is disabled for **Empty bank**. **Add variant** asks for **Group name** before creating a keyswitch variant; cancelling leaves the original untouched. Group names are saved with the bank, including Export/Import. The field appears when editing a velocity group; single articulations keep their own direct menu entry.

## Ending keyswitches

Choose **Type → Ending** in Add / Edit articulation, configure KS note, velocity, KS channel and Delay, and save. The **Ending** submenu contains only records of this type. Ordinary articulation records are excluded. Switching a saved primary record to Ending prepares a separate new record and preserves the original. Select musical notes and apply **Articulations → Open** (or Slap), then **Ending → Slide Down**. The ending is independent: changing it preserves the starting articulation and channel. **Ending → Clear ending** removes only the ending; **Clear articulation** keeps it. Endings cannot serve as the default articulation.

For **Note end**, **Delay (ms)** is the distance **before note-off**. The keyswitch starts while the voice is held and ends with the musical note; there is at least one MIDI tick before note-off. The timing stays inside the note. Very short notes may not have room and are rejected without changing MIDI. Endings follow note moves and length edits while the main script runs. Set KS velocity and KS channel as required by the instrument; musical velocity is preserved. Notes sharing a MIDI channel share its keyswitch state.

Save the project for note assignments and the bank. Editing a preset does not change existing snapshots; select notes and reapply the ending.

## Editing and responsiveness

The Add / Edit window can remain open while notes are moved or resized: existing articulation, Ending and controller links keep following the notes. During the native Quantize Events preview, automatic MIDI writes pause; links are reconciled after closing the dialog. Selection-only changes such as Select all use a separate path and do not regenerate switches. Unchanged playback and scrolling reuse the cached state. Large-item updates use one MIDI buffer write while retaining the musical-note integrity check.

## Moving items to another track

While the main script runs, moving an observed MIDI item to a track with Empty bank (or no stored bank) clears its automatic articulation assignments, owned keyswitches, Ending and owned controllers. Original musical MIDI channels and automatic start offsets are restored. Musical pitches, velocities, ends and selection are preserved; manually drawn notes and unowned controller events are retained. Source and destination track banks are not changed. A destination with a selected bank keeps the carried assignments. Transfers are detected with the MIDI editor closed, after the mouse drag ends, without decoding unchanged items. Undo the item move to recover its previous assignments. The initial project scan seeds existing items. After that, newly appeared takes from paste, duplicate or drag-copy are checked too. Copies within a track with a selected bank retain assignments. Removed identities are pruned so a Redo-restored copy is checked again. Linked pooled copies are left intact and report an unpool requirement, protecting the original MIDI source. No mouse modifier or shortcut is intercepted.
