# ArticulationBox

**By Andrey Novikov** · [All scripts](../README.md)

[**↓ Download package ZIP**](https://github.com/andreynovikov86-cmd/ReaScripts/raw/refs/heads/main/downloads/ArticulationBox.zip) · [Install with ReaPack](../README.md#install--update-via-reapack)

![ArticulationBox](../docs/cards/articulationbox.svg)

By **Andrey Novikov**.

**English** · [Русский](README_RU.md)

User guide: [English](USER_GUIDE.md) · [Русский](USER_GUIDE_RU.md). Open **Help** in the full script menu for offline explanations.

A compact articulation menu for the REAPER MIDI Editor.

One ReaPack package includes the embedded articulation field, a quick menu at the mouse cursor, and a full settings menu. It supports manual and automatic keyswitches, MIDI channel switching, independent track banks, default articulations, keyswitches that follow musical notes, and keyswitch pitch protection during transposition. The script interface is in English.

## Install with ReaPack

Import this repository URL:

```text
https://raw.githubusercontent.com/andreynovikov86-cmd/ReaScripts/main/index.xml
```

In REAPER, open **Extensions > ReaPack > Import repositories** and paste the URL. Then open **Browse packages**, find **ArticulationBox**, choose **Install**, and click **Apply**.

The script requires [js_ReaScriptAPI](https://github.com/juliansader/ReaExtensions) and [ReaImGui](https://github.com/cfillion/reaimgui) for the parameter editor. Install both separately through ReaPack and restart REAPER after installing the extensions.

## First run

Open a MIDI item. In **Actions > MIDI Editor**, run `Articulation_Manager.lua`. Assign a shortcut to `Articulation_Quick_Menu.lua` in the same action section for quick articulation selection. Keep the main script running so it can update linked keyswitches.

Create a bank through **Banks > New**, or choose **Add / Edit articulation** with Empty bank selected to create a bank first. Choose **Default articulation** below Banks for notes without another assignment. Enable **Settings > Run script on startup** for automatic startup. Save your project to restore track bank choices and note assignments.

Personal banks, projects, and user backups are not included in this repository. When moving from a manual installation to ReaPack, reassign your shortcuts to the actions from the new installation.

For a full installation guide in Russian, see [INSTALL_RU](INSTALL_RU.txt). Third-party code acknowledgments are in [THIRD_PARTY_NOTICES](THIRD_PARTY_NOTICES.txt).

## Moving from the former ArticulationBox repository

Existing installations can continue updating through ordinary synchronization: the former compatibility index mirrors new ArticulationBox releases from ReaScripts. Reinstallation is not required for updates. The steps below are only for moving the installation into the shared repository.

1. Stop the old ArticulationBox instance and turn off its **Settings > Run script on startup** option if enabled.
2. In ReaPack, uninstall ArticulationBox from the former **Andrey Novikov** repository, then install **ArticulationBox** from **ReaScripts by Andrey Novikov** using the URL above.
3. Assign your MIDI Editor shortcuts to the newly installed actions. Enable startup again from the new instance if needed.

Track banks and note assignments remain in your REAPER projects. Saved bank templates and preferences use the same locations as before. The former repository retains its release history and an automatically updated compatibility index; development takes place here.

## Articulation editor

Add / Edit articulation uses one compact, resizable window with **Keyswitch**, **Channel**, **KS + Channel**, **Controller**, and **Ending** choices. Play a MIDI key or click a piano-roll key to fill the keyswitch note and velocity, then edit either value if needed. **Save & Next** builds several mappings without reopening the editor. Window size is remembered. The Bank line identifies the destination; the Articulation list selects a new or saved mapping, and Remove articulation deletes a saved mapping. Full-menu choices live under Articulations; same-pitch velocity variants have their own submenus. The shortcut still opens choices directly.

Choose **Before note start** or **After note start** and set Delay in milliseconds. A delayed keyswitch can trigger a loop ending after a chord starts, with independent keyswitch velocity. Automatic keyswitches still follow the musical note’s end.

## Manual keyswitches

You can draw and edit MIDI notes directly on articulation rows. These notes do not receive a default articulation. With a default articulation selected, a manual switch applies within its drawn region and the default returns for later notes. Without a default, the latest switch remains active until another switch or explicit assignment on that MIDI channel.

If you independently change an automatic keyswitch's pitch, position, length, or velocity, it becomes manual. Its previous automatic assignments are removed while the musical notes are preserved. Moving musical notes still moves their linked automatic keyswitches.

When a later keyswitch starts on the same MIDI channel, the earlier keyswitch is shortened to end at that point. Musical note lengths are preserved.

## Updates

To install updates, use **Extensions > ReaPack > Synchronize packages**.

Update the package code, increase `@version` and update `@changelog` in `ArticulationBox/Articulation_Manager.lua`. Commit the files first, then append the matching version to the shared ReaScripts `index.xml` with download links pinned to the full source commit SHA. Retain previous versions for rollback.

## License

ArticulationBox is licensed under the [MIT License](LICENSE.md), which permits use, modification and redistribution, including commercial use, with the required copyright and license notices.

Adapted Gridbox code retains its original MIT copyright and license notice in [THIRD_PARTY_NOTICES](THIRD_PARTY_NOTICES.txt). Both notices are included in the ReaPack package.

### Controllers

Save Pitch Bend or any CC as an independent named preset, or attach it to an articulation. Ready menus show **Controller** when presets are available or assigned controllers can be reset. **Reset controllers** clears controllers from selected notes while preserving articulations. Choose **Full note**, **Note start**, or **Note end**, with Before/After margins and a reset value. **None** is selected initially; Pitch Bend, Mod Wheel and Hold Pedal follow it in the chooser. Controllers follow note edits and Undo/Redo; see the [user guide](USER_GUIDE.md#controllers).

### Ending

**Type → Ending** creates a separate end-of-note keyswitch. The Ending menu lists only these presets. Apply Open or Slap normally, then add a slide from Ending. Changing the primary articulation keeps the ending; Clear ending removes it independently. Delay is measured before note-off.

### Editing and performance

Keep Add / Edit open while moving or resizing notes: links remain active. During the native Quantize Events live preview, automatic MIDI writes pause and resume when the dialog closes. Selection changes such as Select all do not regenerate switches; unchanged playback and scrolling reuse the cached state. Large-item writes are batched while musical-note integrity checks remain enabled.
